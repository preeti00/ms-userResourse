# ms-userResourse
 TechM UserResourse functionality
